CCTV Website - kaise chalayein
==============================
1. Is folder ko unzip karke kahin bhi rakhein (index.html aur frames folder saath rehne chahiye).
2. index.html ko Chrome/Edge mein double-click karke kholein.
   (Scroll animation ke liye best hai ki ise kisi local server se chalayein:
    folder ke andar PowerShell kholke:  python -m http.server 8000
    phir browser mein:  http://localhost:8000 )
3. Badalne layak cheezein index.html mein:
   - Brand naam "Beyond"  -> apna naam
   - Phone "+91 · add number" aur email "add-email@yourdomain.com"
   - Specs mein har "— edit" ki jagah asli value
   - WhatsApp: index.html mein  const WA_NUMBER = ''  mein apna number daalein (jaise '919876543210'),
     tab enquiry form ka 'Send on WhatsApp' button chalu ho jayega
   - Packages mein '₹ edit' ki jagah apni price
